# Upacara Simulator

Developed by **Stargaze Interactives** — Created by **Harvey Jeremy**.
Independent browser-based multiplayer game inspired by Indonesian school flag ceremonies.

## Status
- **Phase 1 (done):** Vite + Three.js client, low-poly school courtyard, flag, student character, third-person camera, username screen, settings (Low/Medium graphics, mouse sensitivity).
- **Not yet implemented:** multiplayer server (Phase 2), ceremony state machine and roles (Phase 3), deployment config (Phase 4). The title screen's connection status says "offline" for this reason.

## Run locally
Prerequisite: Node.js 18+.
```
cd client
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in client/dist
```

## Controls
WASD move · mouse look (click canvas to capture) · wheel zoom · Shift run · Esc settings.

## Configuration
`client/src/config.js` reads `VITE_SERVER_URL` (use `https://` in production). Unused until Phase 2.

## Known limitations
- Verified only by a successful production build; in-browser behavior and frame rate on the target laptop are untested.
- GitHub Pages hosts the static client only; the Node.js server (Phase 2) must be hosted separately.
- No LICENSE file yet — choose one before publishing.
