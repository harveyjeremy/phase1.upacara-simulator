// Phase 2 will use SERVER_URL. Set VITE_SERVER_URL in client/.env.production (use https://).
export const SERVER_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:3001';
export const WORLD_HALF = 38; // playable bounds (square, meters)
export const USERNAME_RE = /^[A-Za-z0-9_ ]{3,20}$/;
