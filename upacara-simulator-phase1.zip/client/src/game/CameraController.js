import * as THREE from 'three';

/** Third-person orbit camera with pointer-lock look, wheel zoom, and simple wall avoidance. */
export class CameraController {
  constructor(camera, canvas, colliders) {
    this.camera = camera;
    this.canvas = canvas;
    this.colliders = colliders;
    this.yaw = 0;          // 0 → camera behind player looking toward -z
    this.pitch = 0.35;
    this.distance = 7;
    this.sensitivity = 1;
    this.enabled = false;
    this._target = new THREE.Vector3();
    this._pos = new THREE.Vector3();

    document.addEventListener('mousemove', (e) => {
      if (!this.enabled || document.pointerLockElement !== canvas) return;
      this.yaw -= e.movementX * 0.0025 * this.sensitivity;
      this.pitch = Math.min(1.2, Math.max(-0.1, this.pitch + e.movementY * 0.0025 * this.sensitivity));
    });
    canvas.addEventListener('wheel', (e) => {
      if (!this.enabled) return;
      this.distance = Math.min(14, Math.max(3, this.distance + Math.sign(e.deltaY) * 0.8));
    }, { passive: true });
  }

  _inside(x, y, z) {
    if (y > 8) return false;
    for (const c of this.colliders) if (x > c.minX && x < c.maxX && z > c.minZ && z < c.maxZ) return true;
    return false;
  }

  update(dt, playerPos) {
    this._target.set(playerPos.x, playerPos.y + 1.5, playerPos.z);
    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    const dir = new THREE.Vector3(Math.sin(this.yaw) * cp, sp, Math.cos(this.yaw) * cp);
    // Shorten the boom if a collider is in the way
    let dist = this.distance;
    for (let s = 1; s <= 12; s++) {
      const t = (s / 12) * this.distance;
      if (this._inside(this._target.x + dir.x * t, this._target.y + dir.y * t, this._target.z + dir.z * t)) { dist = Math.max(1.2, t - 0.6); break; }
    }
    this._pos.copy(this._target).addScaledVector(dir, dist);
    this._pos.y = Math.max(0.4, this._pos.y);
    this.camera.position.lerp(this._pos, 1 - Math.exp(-dt * 14));
    this.camera.lookAt(this._target);
  }
}
