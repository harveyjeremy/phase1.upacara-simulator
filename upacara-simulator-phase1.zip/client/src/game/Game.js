import * as THREE from 'three';
import { SceneManager, QUALITY } from './SceneManager.js';
import { SchoolEnvironment } from './SchoolEnvironment.js';
import { Player } from './Player.js';
import { PlayerController } from './PlayerController.js';
import { CameraController } from './CameraController.js';

/** Owns the render loop and local-player lifecycle. UI talks to it via start/stop/setPaused/applySettings. */
export class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.sm = new SceneManager(canvas);
    this.env = new SchoolEnvironment(this.sm.scene);
    this.cam = new CameraController(this.sm.camera, canvas, this.env.colliders);
    this.clock = new THREE.Clock();
    this.local = null;
    this.running = false;
    this.paused = false;
    this.onPointerUnlock = null; // UI hook: open settings when the lock is lost during play

    document.addEventListener('pointerlockchange', () => {
      if (!document.pointerLockElement && this.running && !this.paused) this.onPointerUnlock?.();
    });
    canvas.addEventListener('click', () => {
      if (this.running && !this.paused && !document.pointerLockElement) canvas.requestPointerLock?.();
    });
    this.sm.camera.position.set(0, 12, 40);
    this.sm.camera.lookAt(0, 3, -10);
    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  applySettings({ quality, sensitivity }) {
    this.sm.setQuality(quality);
    this.env.setDecorVisible(QUALITY[quality].decor);
    this.cam.sensitivity = sensitivity;
  }

  start(username) {
    this.stop();
    this.local = new Player(username, this.sm.scene);
    this.local.position.copy(this.env.spawnPoint);
    this.local.setYaw(Math.PI); // face the flag (-z)
    this.cam.yaw = 0;
    this.controller = new PlayerController(this.local, this.env.colliders, this.cam);
    this.running = true;
    this.setPaused(false);
    this.sm.camera.position.set(0, 4, 21);
  }

  stop() {
    this.running = false;
    this.cam.enabled = false;
    this.controller?.setEnabled(false);
    this.local?.dispose();
    this.local = null;
    if (document.pointerLockElement) document.exitPointerLock();
  }

  setPaused(p) {
    this.paused = p;
    const active = this.running && !p;
    this.cam.enabled = active;
    this.controller?.setEnabled(active);
    if (!active && document.pointerLockElement) document.exitPointerLock();
  }

  _loop() {
    requestAnimationFrame(this._loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.env.update(dt);
    if (this.running && this.local) {
      if (!this.paused) this.controller.update(dt);
      else this.local.animate(dt, 0);
      this.cam.update(dt, this.local.position);
      this.local.updateLabel(this.sm.camera);
    } else {
      // Title-screen idle camera: slow orbit around the courtyard
      const t = performance.now() / 1000 * 0.08;
      this.sm.camera.position.set(Math.sin(t) * 40, 14, Math.cos(t) * 40);
      this.sm.camera.lookAt(0, 3, -4);
    }
    this.sm.render();
  }
}
