import * as THREE from 'three';

const M = (c) => new THREE.MeshLambertMaterial({ color: c });
const shared = {
  head: new THREE.BoxGeometry(0.4, 0.4, 0.4),
  torso: new THREE.BoxGeometry(0.55, 0.65, 0.3),
  arm: new THREE.BoxGeometry(0.16, 0.6, 0.16),
  leg: new THREE.BoxGeometry(0.2, 0.7, 0.2),
  skin: M(0xf0c8a0), hair: M(0x2a1d14), shirt: M(0xffffff), pants: M(0x1f3a8a),
};

/** Low-poly student (white shirt, dark blue trousers) built from boxes. Faces -z at rotation 0 → we use +z forward via yaw. */
export class Player {
  constructor(username, scene) {
    this.scene = scene;
    this.root = new THREE.Group();
    const body = new THREE.Group();
    this.root.add(body);

    const torso = new THREE.Mesh(shared.torso, shared.shirt); torso.position.y = 1.025; body.add(torso);
    const head = new THREE.Mesh(shared.head, shared.skin); head.position.y = 1.55; body.add(head);
    const hair = new THREE.Mesh(shared.head, shared.hair); hair.scale.set(1.05, 0.4, 1.05); hair.position.y = 1.7; body.add(hair);

    const limb = (geo, mat, x, y, pivotY) => {
      const pivot = new THREE.Group(); pivot.position.set(x, pivotY, 0);
      const m = new THREE.Mesh(geo, mat); m.position.y = y - pivotY; pivot.add(m); body.add(pivot); return pivot;
    };
    this.armL = limb(shared.arm, shared.shirt, -0.36, 1.05, 1.32);
    this.armR = limb(shared.arm, shared.shirt, 0.36, 1.05, 1.32);
    this.legL = limb(shared.leg, shared.pants, -0.14, 0.35, 0.7);
    this.legR = limb(shared.leg, shared.pants, 0.14, 0.35, 0.7);

    this.body = body;
    this.phase = 0;
    this.speed = 0;
    scene.add(this.root);

    this.label = document.createElement('div');
    this.label.className = 'label';
    this.label.textContent = username; // textContent: safe against HTML injection
    document.body.appendChild(this.label);
    this._v = new THREE.Vector3();
  }

  get position() { return this.root.position; }

  /** yaw: radians; character's front is +z at yaw 0. */
  setYaw(y) { this.root.rotation.y = y; }

  animate(dt, speed) {
    this.speed = speed;
    if (speed > 0.1) {
      this.phase += dt * (speed > 5 ? 11 : 7);
      const s = Math.sin(this.phase) * 0.7;
      this.legL.rotation.x = s; this.legR.rotation.x = -s;
      this.armL.rotation.x = -s; this.armR.rotation.x = s;
      this.body.position.y = Math.abs(Math.sin(this.phase)) * 0.04;
    } else { // idle: gentle breathing, limbs relaxed
      this.phase += dt * 1.8;
      for (const l of [this.legL, this.legR, this.armL, this.armR]) l.rotation.x *= 0.8;
      this.body.position.y = Math.sin(this.phase) * 0.012;
    }
  }

  updateLabel(camera, visible = true) {
    this._v.copy(this.root.position); this._v.y += 2.1;
    this._v.project(camera);
    if (!visible || this._v.z > 1) { this.label.style.display = 'none'; return; }
    this.label.style.display = 'block';
    const x = (this._v.x * 0.5 + 0.5) * window.innerWidth;
    const y = (-this._v.y * 0.5 + 0.5) * window.innerHeight;
    this.label.style.transform = `translate(${x}px,${y}px) translate(-50%,-100%)`;
  }

  dispose() {
    this.scene.remove(this.root);
    this.label.remove();
  }
}
