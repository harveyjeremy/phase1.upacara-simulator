import { WORLD_HALF } from '../config.js';

const RADIUS = 0.4;
const WALK = 4, RUN = 7.5;

/** Keyboard movement relative to camera yaw, with AABB collision and map bounds. */
export class PlayerController {
  constructor(player, colliders, cameraCtl) {
    this.player = player;
    this.colliders = colliders;
    this.cam = cameraCtl;
    this.keys = new Set();
    this.enabled = false;
    this._down = (e) => { if (this.enabled) this.keys.add(e.code); };
    this._up = (e) => this.keys.delete(e.code);
    window.addEventListener('keydown', this._down);
    window.addEventListener('keyup', this._up);
    window.addEventListener('blur', () => this.keys.clear());
  }

  setEnabled(v) { this.enabled = v; if (!v) this.keys.clear(); }

  _blocked(x, z) {
    if (Math.abs(x) > WORLD_HALF || Math.abs(z) > WORLD_HALF) return true;
    for (const c of this.colliders) {
      if (x > c.minX - RADIUS && x < c.maxX + RADIUS && z > c.minZ - RADIUS && z < c.maxZ + RADIUS) return true;
    }
    return false;
  }

  update(dt) {
    const k = this.keys;
    let f = (k.has('KeyW') ? 1 : 0) - (k.has('KeyS') ? 1 : 0);
    let r = (k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0);
    let speed = 0;
    const p = this.player.position;
    if (f || r) {
      const len = Math.hypot(f, r); f /= len; r /= len;
      const yaw = this.cam.yaw; // camera sits behind player; forward = away from camera
      const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
      const rx = -fz, rz = fx; // right-hand vector (y-up)
      const dx = fx * f + rx * r, dz = fz * f + rz * r;
      speed = (k.has('ShiftLeft') || k.has('ShiftRight')) ? RUN : WALK;
      const nx = p.x + dx * speed * dt, nz = p.z + dz * speed * dt;
      if (!this._blocked(nx, p.z)) p.x = nx;   // axis-separated: slide along walls
      if (!this._blocked(p.x, nz)) p.z = nz;
      // Face movement direction (character front is +z)
      const target = Math.atan2(dx, dz);
      let d = target - this.player.root.rotation.y;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.player.setYaw(this.player.root.rotation.y + d * Math.min(1, dt * 12));
    }
    this.player.animate(dt, speed);
  }
}
