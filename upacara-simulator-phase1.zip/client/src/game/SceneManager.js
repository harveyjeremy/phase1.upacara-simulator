import * as THREE from 'three';

export const QUALITY = {
  low: { pixelRatio: 0.7, decor: false },
  medium: { pixelRatio: 1.5, decor: true },
};

export class SceneManager {
  constructor(canvas) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x8fcdf0);
    this.scene.fog = new THREE.Fog(0x8fcdf0, 60, 140);
    this.camera = new THREE.PerspectiveCamera(60, 1, 0.1, 200);

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x6b7a5a, 1.0));
    const sun = new THREE.DirectionalLight(0xfff3d6, 1.2);
    sun.position.set(30, 50, 20);
    this.scene.add(sun);

    this.quality = 'medium';
    window.addEventListener('resize', () => this.resize());
    this.resize();
  }

  setQuality(q) {
    if (!QUALITY[q]) return;
    this.quality = q;
    this.resize();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, QUALITY[this.quality].pixelRatio);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
  }

  render() { this.renderer.render(this.scene, this.camera); }
}
