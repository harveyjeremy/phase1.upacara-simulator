import * as THREE from 'three';

const mats = new Map();
const mat = (c) => {
  if (!mats.has(c)) mats.set(c, new THREE.MeshLambertMaterial({ color: c }));
  return mats.get(c);
};
const boxGeo = new THREE.BoxGeometry(1, 1, 1);

function box(w, h, d, color, x, y, z, parent) {
  const m = new THREE.Mesh(boxGeo, mat(color));
  m.scale.set(w, h, d);
  m.position.set(x, y, z);
  parent.add(m);
  return m;
}

/** Builds the school courtyard. Exposes `colliders` (world AABBs) and `spawnPoint`. */
export class SchoolEnvironment {
  constructor(scene) {
    this.group = new THREE.Group();
    this.decor = new THREE.Group(); // hidden on Low quality
    this.colliders = [];
    this.spawnPoint = new THREE.Vector3(0, 0, 14);
    this.flagPole = { x: 0, z: -14, height: 10 };
    this._t = 0;

    this._ground();
    this._ceremonyArea();
    this._flag();
    // Buildings face the courtyard. rotY maps local +z (front) to world direction.
    this._building({ x: 0, z: -30, w: 56, d: 10, h: 7, rotY: 0 });
    this._building({ x: -31, z: 3, w: 50, d: 8, h: 6, rotY: Math.PI / 2 });
    this._building({ x: 31, z: 3, w: 50, d: 8, h: 6, rotY: -Math.PI / 2 });
    this._southWall();
    this._trees();
    this.group.add(this.decor);
    scene.add(this.group);
  }

  setDecorVisible(v) { this.decor.visible = v; }

  _addCollider(cx, cz, sx, sz) {
    this.colliders.push({ minX: cx - sx / 2, maxX: cx + sx / 2, minZ: cz - sz / 2, maxZ: cz + sz / 2 });
  }

  _ground() {
    const g = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), mat(0x5c8f46));
    g.rotation.x = -Math.PI / 2;
    this.group.add(g);
    const pave = new THREE.Mesh(new THREE.PlaneGeometry(58, 60), mat(0xb9bcc0));
    pave.rotation.x = -Math.PI / 2;
    pave.position.set(0, 0.02, 4);
    this.group.add(pave);
    // path to gate
    const path = new THREE.Mesh(new THREE.PlaneGeometry(8, 14), mat(0x9a9da2));
    path.rotation.x = -Math.PI / 2;
    path.position.set(0, 0.03, 36);
    this.group.add(path);
  }

  _ceremonyArea() {
    // Assembly formation lines (white strips) and boundary
    for (let i = 0; i < 6; i++) box(24, 0.02, 0.15, 0xffffff, 0, 0.05, -4 + i * 3.2, this.group);
    box(0.15, 0.02, 16, 0xffffff, -12, 0.05, 4, this.group);
    box(0.15, 0.02, 16, 0xffffff, 12, 0.05, 4, this.group);
    // Officer platform
    const px = 0, pz = -9;
    box(8, 0.5, 3, 0xe6e6e6, px, 0.25, pz, this.group);
    box(8.02, 0.12, 3.02, 0xd62828, px, 0.3, pz, this.group);
    this._addCollider(px, pz, 8, 3);
    // Officer marker spots
    for (const dx of [-2.5, 0, 2.5]) {
      const s = new THREE.Mesh(new THREE.CircleGeometry(0.4, 12), mat(0xffd76a));
      s.rotation.x = -Math.PI / 2;
      s.position.set(dx, 0.56, pz);
      this.group.add(s);
    }
  }

  _flag() {
    const { x, z, height } = this.flagPole;
    box(1.2, 0.3, 1.2, 0x888888, x, 0.15, z, this.group);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, height, 8), mat(0xcfcfcf));
    pole.position.set(x, height / 2, z);
    this.group.add(pole);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), mat(0xffd76a));
    ball.position.set(x, height + 0.15, z);
    this.group.add(ball);
    this._addCollider(x, z, 1.2, 1.2);

    // Flag: red top half, white bottom half via vertex colors. 3:2 ratio.
    const W = 3, H = 2, sx = 14, sy = 8;
    const geo = new THREE.PlaneGeometry(W, H, sx, sy);
    const flagMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    this.flagGeo = this._splitColors(geo);
    this.flag = new THREE.Mesh(this.flagGeo, flagMat);
    this.flagBase = this.flagGeo.attributes.position.array.slice();
    this.flag.position.set(x + W / 2 + 0.07, height - H / 2 - 0.2, z);
    this.group.add(this.flag);
  }

  /** Convert to non-indexed geometry and color each triangle by its centroid height for a crisp red/white split. */
  _splitColors(geo) {
    const g = geo.toNonIndexed();
    const p = g.attributes.position;
    const col = new Float32Array(p.count * 3);
    for (let i = 0; i < p.count; i += 3) {
      const cy = (p.getY(i) + p.getY(i + 1) + p.getY(i + 2)) / 3;
      const c = cy > 0 ? [0.84, 0.16, 0.16] : [1, 1, 1];
      for (let k = 0; k < 3; k++) col.set(c, (i + k) * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }

  _building({ x, z, w, d, h, rotY }) {
    const b = new THREE.Group();
    b.position.set(x, 0, z);
    b.rotation.y = rotY;
    box(w, h, d, 0xf1e5c8, 0, h / 2, 0, b);              // walls
    box(w + 0.6, 0.5, d + 0.6, 0xb9503a, 0, h + 0.25, 0, b); // roof slab
    box(w + 0.8, 0.9, d + 0.8, 0x8f3f2e, 0, h + 0.95, 0, b); // roof cap
    box(w, 0.8, d + 0.1, 0xc9b78f, 0, 0.4, 0, b);         // base stripe
    // Front face windows and door (local +z)
    const fz = d / 2 + 0.05;
    const doorX = 0;
    box(2.4, 3.2, 0.2, 0x6b4a2f, doorX, 1.6, fz, b);
    const rows = h > 6.5 ? [2.4, 5.0] : [2.6];
    const n = Math.floor((w - 4) / 4);
    for (let r = 0; r < rows.length; r++) {
      for (let i = 0; i < n; i++) {
        const wx = -((n - 1) * 4) / 2 + i * 4;
        if (r === 0 && Math.abs(wx - doorX) < 2.5) continue;
        box(1.8, 1.5, 0.15, 0x6fb7d8, wx, rows[r], fz, b);
        box(2.0, 0.12, 0.2, 0xffffff, wx, rows[r] - 0.8, fz, b);
      }
    }
    // Covered walkway (teras) along the front
    box(w - 2, 0.2, 2.2, 0xd8d0b8, 0, 3.3, fz + 1.1, b);
    for (let i = 0; i < Math.floor(w / 8) + 1; i++) {
      box(0.3, 3.3, 0.3, 0xe6e0cc, -w / 2 + 1 + i * ((w - 2) / Math.floor(w / 8)), 1.65, fz + 2.1, b);
    }
    this.group.add(b);
    // World-space collider of the building footprint (swap extents when rotated 90°)
    const swap = Math.abs(Math.sin(rotY)) > 0.5;
    this._addCollider(x, z, swap ? d : w, swap ? w : d);
  }

  _southWall() {
    for (const sign of [-1, 1]) {
      const cx = sign * 20;
      box(32, 1.8, 0.6, 0xe9dfc3, cx, 0.9, 34, this.group);
      this._addCollider(cx, 34, 32, 0.6);
      box(1, 2.6, 1, 0xd62828, sign * 4.5, 1.3, 34, this.group);
    }
  }

  _trees() {
    const trunkG = new THREE.CylinderGeometry(0.2, 0.3, 2, 6);
    const leafG = new THREE.ConeGeometry(1.6, 3, 7);
    const spots = [[-24, -20], [24, -20], [-24, 12], [24, 12], [-24, 26], [24, 26], [-14, 28], [14, 28], [-20, -8], [20, -8]];
    for (const [x, z] of spots) {
      const t = new THREE.Mesh(trunkG, mat(0x6b4a2f));
      t.position.set(x, 1, z);
      const l1 = new THREE.Mesh(leafG, mat(0x2f7d3a));
      l1.position.set(x, 3.4, z);
      const l2 = new THREE.Mesh(leafG, mat(0x3a8f45));
      l2.position.set(x, 4.8, z);
      l2.scale.setScalar(0.75);
      this.decor.add(t, l1, l2);
      this._addCollider(x, z, 0.8, 0.8);
    }
    // Benches
    for (const x of [-17, 17]) {
      box(2.4, 0.15, 0.7, 0x7a5230, x, 0.5, 20, this.decor);
      box(2.4, 0.5, 0.1, 0x7a5230, x, 0.85, 20.3, this.decor);
    }
  }

  update(dt) {
    this._t += dt;
    const p = this.flagGeo.attributes.position;
    const base = this.flagBase;
    for (let i = 0; i < p.count; i++) {
      const x = base[i * 3];
      const f = Math.max(0, (x + 1.5) / 3);
      p.setZ(i, Math.sin(f * 7 - this._t * 4) * 0.18 * f);
      p.setY(i, base[i * 3 + 1] + Math.sin(f * 5 - this._t * 3) * 0.04 * f);
    }
    p.needsUpdate = true;
  }
}
