import './styles/main.css';
import { Game } from './game/Game.js';
import { MainMenu } from './ui/MainMenu.js';
import { GameHUD } from './ui/GameHUD.js';
import { Settings } from './ui/Settings.js';

const game = new Game(document.getElementById('game-canvas'));
const settings = new Settings((v) => game.applySettings(v));

let lastUnlock = 0;
const openSettings = () => { game.setPaused(true); hud.setSettingsOpen(true); };
const closeSettings = () => {
  hud.setSettingsOpen(false); game.setPaused(false);
  game.canvas.requestPointerLock?.();
};
const toTitle = () => { game.stop(); hud.hide(); menu.show(); };

const hud = new GameHUD({ onOpenSettings: openSettings, onResume: closeSettings, onDisconnect: toTitle });
const menu = new MainMenu((name) => {
  menu.hide(); hud.show(name); game.start(name);
  game.canvas.requestPointerLock?.();
});

// Esc while pointer is locked releases the lock (no keydown fires) → open settings.
game.onPointerUnlock = () => { lastUnlock = performance.now(); if (!hud.settingsOpen) openSettings(); };
window.addEventListener('keydown', (e) => {
  if (e.code !== 'Escape' || !game.running) return;
  if (performance.now() - lastUnlock < 250) return;
  hud.settingsOpen ? closeSettings() : openSettings();
});
menu.show();
