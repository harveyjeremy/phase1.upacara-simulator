/** In-game HUD: name, player count, status, settings overlay toggle. */
export class GameHUD {
  constructor({ onOpenSettings, onResume, onDisconnect }) {
    this.hud = document.getElementById('hud');
    this.settings = document.getElementById('settings');
    this.hint = document.getElementById('click-hint');
    document.getElementById('open-settings').addEventListener('click', onOpenSettings);
    document.getElementById('resume').addEventListener('click', onResume);
    document.getElementById('disconnect').addEventListener('click', onDisconnect);
  }
  show(username) {
    document.getElementById('hud-name').textContent = username; // textContent: safe
    this.hud.classList.remove('hidden');
  }
  hide() { this.hud.classList.add('hidden'); this.settings.classList.add('hidden'); }
  setSettingsOpen(open) {
    this.settings.classList.toggle('hidden', !open);
    this.hint.classList.toggle('hidden', open);
  }
  get settingsOpen() { return !this.settings.classList.contains('hidden'); }
}
