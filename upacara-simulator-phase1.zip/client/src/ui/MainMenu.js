import { USERNAME_RE } from '../config.js';

/** Title screen + username entry. Phase 1 validates locally; Phase 2 will add server-side validation. */
export class MainMenu {
  constructor(onPlay) {
    this.el = document.getElementById('menu');
    this.input = document.getElementById('username');
    this.err = document.getElementById('username-error');
    const play = () => {
      const name = this.input.value.trim().replace(/\s+/g, ' ');
      if (!USERNAME_RE.test(name)) {
        this.err.textContent = 'Use 3–20 characters: letters, numbers, underscores, spaces.';
        return;
      }
      this.err.textContent = '';
      onPlay(name);
    };
    document.getElementById('play').addEventListener('click', play);
    this.input.addEventListener('keydown', (e) => { if (e.key === 'Enter') play(); });
  }
  show() { this.el.classList.remove('hidden'); this.input.focus(); }
  hide() { this.el.classList.add('hidden'); }
}
