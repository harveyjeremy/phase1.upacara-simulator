const KEY = 'upacara.settings';
const DEFAULTS = { quality: 'medium', sensitivity: 1 };

/** Local-only display preferences (no player profile or progress is stored). */
export class Settings {
  constructor(onChange) {
    this.onChange = onChange;
    this.values = { ...DEFAULTS };
    try { Object.assign(this.values, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch { /* ignore */ }
    if (!['low', 'medium'].includes(this.values.quality)) this.values.quality = 'medium';
    this.gfx = document.getElementById('gfx');
    this.sens = document.getElementById('sens');
    this.gfx.value = this.values.quality;
    this.sens.value = this.values.sensitivity;
    this.gfx.addEventListener('change', () => this._save());
    this.sens.addEventListener('input', () => this._save());
    this.onChange(this.values);
  }
  _save() {
    this.values = { quality: this.gfx.value, sensitivity: parseFloat(this.sens.value) };
    try { localStorage.setItem(KEY, JSON.stringify(this.values)); } catch { /* ignore */ }
    this.onChange(this.values);
  }
}
